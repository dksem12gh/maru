using UnityEngine;

namespace DigitalMaru
{
    public enum ResultWindowType
    {
        SingleTime,
        Count,
        SingleTimeAndCount,
        TotalScore
    }

    public class ResultWindowFactory : MonoBehaviour
    {
        [SerializeField] private ResultWindowType windowType = ResultWindowType.SingleTime;
        [SerializeField] private GameObject resultWindowPrefab;


        ResultWindow resultWnd = null;

        private void OnDestroy()
        {
            Remove();
        }
        public void Remove()
        {
            if (resultWnd != null)
            {
                Object.Destroy(resultWnd.gameObject);
                resultWnd = null;
            }
        }

        ResultWindow GetOrCreate()
        {
            if (resultWnd != null) return resultWnd;
            var go = Instantiate(resultWindowPrefab, transform);
            resultWnd = go.GetComponent<ResultWindow>();
            return resultWnd;
        }

        public void CreateAndShow(params ResultData[] datas)
        {
            CreateAndShow(windowType, datas);
        }

        public void CreateAndShow(ResultWindowType wndType, params ResultData[] datas)
        {
            switch (wndType)
            {
                case ResultWindowType.SingleTimeAndCount:
                    CreateAndShowSingleTimeAndCountWindow(datas);
                    break;
                case ResultWindowType.Count:
                    CreateAndShowCountWindow(datas);
                    break;
                case ResultWindowType.SingleTime:
                    CreateAndShowSingleTimeWindow(datas);
                    break;
                case ResultWindowType.TotalScore:
                    CreateAndShowTotalScoreWindow(datas);
                    break;
            }
        }

        void CreateAndShowSingleTimeAndCountWindow (params ResultData[] datas)
        {
            Remove();
            var wnd = GetOrCreate();
            wnd.SetDataTimeCount(datas);
            wnd.Show();
            wnd.PlayAniTimeCount();
        }

        void CreateAndShowSingleTimeWindow(params ResultData[] datas)
        {
            Remove();
            var wnd = GetOrCreate();
            wnd.SetDataTimeCount(datas);
            wnd.Show();
            wnd.PlayAniSingleTime();
        }

        void CreateAndShowCountWindow (params ResultData[] datas)
        {
            Remove();
            var wnd = GetOrCreate();
            wnd.SetDataCount(datas);
            wnd.Show();
            wnd.PlayAniCount();
        }
        void CreateAndShowTotalScoreWindow(params ResultData[] datas)
        {
            Remove();
            var wnd = GetOrCreate();
            wnd.SetTotal(datas);
            wnd.Show();
            wnd.PlayTotalScore();
        }
    }
}
