using System.Collections;
using UnityEngine;
using UnityEngine.Localization;


namespace DigitalMaru
{

    public class TitleWindowFactory : MonoBehaviour
    {
        [SerializeField] private GameObject titlePrefab;
        [SerializeField] private LocalizedString titleString;

        [System.Serializable]                
        public class Extra
        {
            public bool use = false;
            public Vector3 localPosition = Vector3.zero;
            public Vector3 localScale = Vector3.one;
        }
        [Header("추가 설정")]
        [SerializeField] private Extra extra;


        // This window will be destroyed after delaytime.
        const float delayTime = 4.3f;   
        GameObject titleGo = null;

        private void OnDestroy()
        {
            Remove();
        }

        public void Create ()
        {
            Remove();
            titleGo = Instantiate(titlePrefab, transform);
            titleGo.GetComponent<TitleWindow>().SetTitle(titleString.GetLocalizedString());
            if (extra.use)
            {
                titleGo.transform.localPosition = extra.localPosition;
                titleGo.transform.localScale = extra.localScale;
            }
        }

        public IEnumerator CreateAndRemoveWithDelayed()
        {
            Create();            
            yield return YieldInstructionCache.WaitForSeconds(delayTime);
            Remove();
        }

        public void Remove ()
        {
            if(titleGo != null)
            {
                Object.Destroy(titleGo);
                titleGo = null;
            }

        }
    }
}
