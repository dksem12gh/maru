using UnityEngine;


namespace DigitalMaru.Common
{
    public class InOutZoneTouchPad : TouchPad
    {
        [SerializeField] private TouchPad InTouchPad;
        [SerializeField] private TouchPad OutTouchPad;

        public override int Len => InTouchPad.Len;

        public override bool AllPressed => InTouchPad.AllPressed;
        public override bool FailPressed => OutTouchPad.FailPressed | !AnyPressed;
        public override bool AnyPressed => InTouchPad.AnyPressed;

         void OnEnable()
        {
            InTouchPad.TouchEvent += OnSuccessTouch;
            OutTouchPad.TouchEvent += OnFailedTouch;
        }


        void OnDisable()
        {
            InTouchPad.TouchEvent -= OnSuccessTouch;
            OutTouchPad.TouchEvent -= OnFailedTouch;
        }

        void OnSuccessTouch(TouchPad touchPad)
        {
            InvokeTouchEvent();
        }

        void OnFailedTouch(TouchPad touchPad)
        {
            InvokeTouchEvent();
        }

        public override void SetActive(bool value)
        {            
            InTouchPad.SetActive(value);
            OutTouchPad.SetActive(value);
        }

        public override void SetLock(bool isLock)
        {
            InTouchPad.SetLock(isLock);
            OutTouchPad.SetLock(isLock);
        }

        public override void SetLock(bool isLock, int index)
        {
            InTouchPad.SetLock(isLock, index);
            OutTouchPad.SetLock(isLock, index);
        }

        public override bool GetPressed(int index)
        {
            return InTouchPad.GetPressed(index);
        }

        public override bool TryGetTouch(int index, out Touch touch)
        {
            return InTouchPad.TryGetTouch(index, out touch);
        }

        public override void ResetTouch()
        {
            InTouchPad.ResetTouch();
            OutTouchPad.ResetTouch();
        }
    }
}
