using UnityEngine;

namespace DigitalMaru.Common
{
    public class MultipleTouchPad : TouchPad
    {
        [SerializeField] private Touch[] touchList;
        public override int Len => touchList == null? 0 : touchList.Length;

        public override bool FailPressed => false;

        public override bool AllPressed
        {
            get
            {                
                foreach(var touch in touchList)
                {
                    if (touch.Pressed is false) return false;             
                }
                return true;
            }
        }

        public override bool AnyPressed
        {
            get
            {
                foreach (var touch in touchList)
                    if (touch.Pressed) return true;
                return false;
            }
        }

        private void OnEnable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent += InvokeTouchEvent;
                touch.UpdateEvent += InvokeTouchEvent;
                touch.ReleaseEvent += InvokeTouchEvent;
            }
        }

        private void OnDisable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent -= InvokeTouchEvent;
                touch.UpdateEvent -= InvokeTouchEvent;
                touch.ReleaseEvent -= InvokeTouchEvent;
            }
        }

        public override void SetLock(bool isLock)
        {
            foreach (var touch in touchList)                
                touch.SetLock(isLock);
        }

        public override void SetLock(bool isLock, int index)
        {
            int i = 0;
            foreach (var touch in touchList)
            {                
                if(i == index)
                    touch.SetLock(isLock, index);
                i++;
            }
        }

        public override void SetActive(bool value)
        {
            gameObject.SetActive(value);
        }

        public override bool TryGetTouch(int index, out Touch touch)
        {
            if(index < touchList.Length)
            {
                touch = touchList[index];
                return true;
            }
            touch = null;
            return false;
        }

        public override bool GetPressed(int index)
        {
            if(TryGetTouch(index, out var touch))
                return touch.Pressed;
            return false;
        }

        public override void ResetTouch()
        {
            foreach (var touch in touchList)
                touch.ResetTouch();
        }       
    }
}
