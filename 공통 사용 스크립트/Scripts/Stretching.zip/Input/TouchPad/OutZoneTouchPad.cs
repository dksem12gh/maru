namespace DigitalMaru.Common
{
    public class OutZoneTouchPad : MultipleTouchPad
    {
        public override bool FailPressed
        {
            get => AnyPressed;
        }
    }
}
