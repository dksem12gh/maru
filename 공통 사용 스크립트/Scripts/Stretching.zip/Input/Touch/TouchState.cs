using System;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class TouchState : IDisposable
    {
        public event Action PressedEvent;
        public event Action UpdateEvent;
        public event Action ReleaseEvent;

        readonly TouchEventHandler touchEventHandler;      
        
        public bool Pressed
        {
            get;
            private set;
        } = false;

        public bool IsLock => touchEventHandler.enabled is false;

        public TouchState(TouchEventHandler touchEventHandler)
        {
            this.touchEventHandler = touchEventHandler;
            Listen();
        }

        void Listen()
        {
            touchEventHandler.m_PressedEvent.AddListener(OnPressed);
            touchEventHandler.m_UpdatedEvent.AddListener(OnUpdate);
            touchEventHandler.m_ReleasedEvent.AddListener(OnRelease);
        }

        void UnListen()
        {
            touchEventHandler.m_PressedEvent.RemoveListener(OnPressed);
            touchEventHandler.m_UpdatedEvent.RemoveListener(OnUpdate);
            touchEventHandler.m_ReleasedEvent.RemoveListener(OnRelease);
        }

        public void ResetState()
        {
            touchEventHandler.enabled = true;            
            Release(true);
        }

        public void SetLock(bool isLock)
        {
            touchEventHandler.enabled = isLock is false;
            Release(true);
        }

        public void SetLock(bool isLock,int index)
        {
            touchEventHandler.enabled = isLock is false;
            Release(true);
        }

        void OnPressed(Vector3 _)
        {
            if (IsLock) return;
            Press();
        }

        void OnUpdate(Vector3 _)
        {
            if (IsLock) return;

            UpdateEvent?.Invoke();
        }

        void OnRelease(Vector3 _)
        {
            if (IsLock) return;
            
            Release(true);
        }

        public void Press()
        {
            if (Pressed is false)
            {
                Pressed = true;
                PressedEvent?.Invoke();
            }
        }

        public void Release(bool notify)
        {
            if (Pressed)
            {
                Pressed = false;
                if(notify)
                    ReleaseEvent?.Invoke();
            }
        }

        public void Dispose()
        {
            UnListen();
        }
    }
}
