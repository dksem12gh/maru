using UnityEngine;

namespace DigitalMaru.Common
{
    public abstract class SingleTouch : Touch
    {
        [SerializeField]  protected TouchEventHandler touchEventHandler;

        bool pressed = false;
        public override bool Pressed
        {
            get => pressed;       
        }

        bool IsLock => touchEventHandler.enabled is false;

        protected virtual void Reset()
        {
            touchEventHandler = GetComponent<TouchEventHandler>();
        }

        protected virtual void OnEnable()
        {
            touchEventHandler.m_PressedEvent.AddListener(OnPressed);
            touchEventHandler.m_UpdatedEvent.AddListener(OnUpdate);
            touchEventHandler.m_ReleasedEvent.AddListener(OnRelease);
        }

        protected virtual void OnDisable()
        {
            touchEventHandler.m_PressedEvent.RemoveListener(OnPressed);
            touchEventHandler.m_UpdatedEvent.RemoveListener(OnUpdate);
            touchEventHandler.m_ReleasedEvent.RemoveListener(OnRelease);
        }

        public override void ResetTouch()
        {
            enabled = true;
            touchEventHandler.enabled = true;
            if (pressed)
                Release(true);
        }

        public override void SetLock(bool isLock)
        {
            //this.enabled = isLock is false;
            touchEventHandler.SetLock(isLock);                        
        }

        public override void SetLock(bool isLock, int index)
        {
            touchEventHandler.SetLock(isLock, index);
        }

        public override void SetActive(bool active)
        {
            //if (pressed)
            //{
            //    Release(false);                
            //}
            pressed = false;
            touchEventHandler.enabled = active;
            this.enabled = active;
        }

        void OnPressed(Vector3 _)
        {
            if (IsLock) return;
            if (Pressed is false)
                Press();
        }


        void OnUpdate(Vector3 _)
        {
            if (IsLock) return;

            //if (Pressed is false)
            //    Press();
            InvokeUpdateEvent();
        }

        void OnRelease(Vector3 _)
        {
            if (IsLock) return;
            if (Pressed)
            {
                Release(true);
            }
        }

        protected virtual void Press()
        {            
            pressed = true;
            InvokePressedEvent();
        }

        protected virtual void Release(bool notify)
        {
            pressed = false;
            if (notify)
            {                
                InvokeReleaseEvent();
            }
        }
    }
}
