using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace DigitalMaru.Common
{
    [RequireComponent(typeof(TouchEventHoldingHandler))]
    public class BoundaryTouch : SingleTouch
    {        

        public override void SetActive(bool active)
        {
            base.SetActive(active);
            gameObject.SetActive(active);
        }
    }
}
