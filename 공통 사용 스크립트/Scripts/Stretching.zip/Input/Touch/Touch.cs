using UnityEngine;
using System;

namespace DigitalMaru.Common
{
    public abstract class Touch : MonoBehaviour
    {
        public event Action PressedEvent;
        public event Action UpdateEvent;
        public event Action ReleaseEvent;
        abstract public bool Pressed { get; }

        abstract public void ResetTouch();
        abstract public void SetLock(bool isLock);
        abstract public void SetLock(bool isLock,int index);

        abstract public void SetActive(bool active);

        protected void InvokePressedEvent() => PressedEvent?.Invoke();
        protected void InvokeUpdateEvent() => UpdateEvent?.Invoke();
        protected void InvokeReleaseEvent() => ReleaseEvent?.Invoke();
    }
}
