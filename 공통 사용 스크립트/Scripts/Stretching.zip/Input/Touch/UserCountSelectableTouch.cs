using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace DigitalMaru.Common
{
    /// <summary>
    /// selectionCount 이상 버튼 터치시 True 다른 버튼도 계속 터치 가능
    /// </summary>
    public class UserCountSelectableTouch : Touch
    {
        [SerializeField] List<Touch> touchList = new List<Touch>();

        public int selectionCount = 2;

        public override bool Pressed => PressedCount >= selectionCount;

        //bool MultiplePressed => selectionCount < PressedCount;

        int PressedCount
        {
            get
            {
                int count = 0;
                foreach (var touch in touchList)
                {
                    if (touch.Pressed) count += 1;
                }
                return count;
            }
        }


        void OnEnable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent += OnPressed;
                touch.UpdateEvent += OnUpdated;
                touch.ReleaseEvent += OnRelease;
            }
        }

        void OnDisable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent -= OnPressed;
                touch.UpdateEvent -= OnUpdated;
                touch.ReleaseEvent -= OnRelease;
            }
        }
        public override void ResetTouch()
        {
            foreach (var touch in touchList)
                touch.ResetTouch();
        }

        public override void SetActive(bool active)
        {
            foreach(var touch in touchList)
                touch.SetActive(active);
        }

        public override void SetLock(bool isLock)
        {
            foreach (var touch in touchList)
                touch.SetLock(isLock);
        }
        public override void SetLock(bool isLock,int index)
        {
            int num = 0;
            foreach (var touch in touchList)
            {
                if(num == index)
                    touch.SetLock(isLock);
                num++;
            }
        }

        void OnPressed()
        {
            UpdateTouches();
            InvokePressedEvent();
        }

        void OnUpdated()
        {
            UpdateTouches();
            InvokeUpdateEvent();
        }

        void OnRelease()
        {
            UpdateTouches();
            InvokeReleaseEvent();
        }

        void UpdateTouches()
        {
            if(PressedCount == 0)
                EnableAllTouch();
            else
            {
                //if (Pressed)
                //    DisableOthers();                
            }            
        }

        void EnableAllTouch ()
        {
            foreach (var touch in touchList)
            {   
                touch.SetActive(true);
            }
        }

        void DisableOthers()
        {
            foreach (var touch in touchList)
            {
                if (touch.Pressed is false)
                {
                    touch.SetActive(false);
                }
            }
        }
    }
}
