using UnityEngine;

namespace DigitalMaru.Common
{
    public class DeactiveTouchablePlayerTouch : Touch
    {
        [SerializeField] TouchEventHandler touchEventHandler;
        [SerializeField] PlayerTouchAnimator myAnimator;

        TouchState touchState;
        TouchState GetTouchState
        {
            get => touchState ??= new TouchState(touchEventHandler);
        }

        public override bool Pressed => GetTouchState.Pressed;


        bool isActive = true;

        void Reset()
        {
            touchEventHandler = GetComponent<TouchEventHandler>();
            myAnimator = GetComponent<PlayerTouchAnimator>();
        }

        void OnDestroy()
        {
            touchState?.Dispose();
            touchState = null;
        }

        void OnEnable()
        {
            GetTouchState.PressedEvent += OnPressed;
            GetTouchState.UpdateEvent += OnUpdate;
            GetTouchState.ReleaseEvent += OnRelease;
        }

         void OnDisable()
        {
            GetTouchState.PressedEvent -= OnPressed;
            GetTouchState.UpdateEvent -= OnUpdate;
            GetTouchState.ReleaseEvent -= OnRelease;
        }

        public override void ResetTouch()
        {         
            GetTouchState.ResetState();
        }

        public override void SetLock(bool isLock)
        {
            GetTouchState.SetLock(isLock);
        }

        public override void SetLock(bool isLock,int index)
        {
            GetTouchState.SetLock(isLock,index);
        }

        public override void SetActive(bool active)
        {
            isActive = active;
            GetTouchState.Release(false);
            if (isActive) myAnimator.Normal();
            else myAnimator.Deactive();
        }

        void OnPressed()
        {
            myAnimator.Press();
            InvokePressedEvent();
        }


        void OnUpdate()
        {
            InvokeUpdateEvent();
        }

        void OnRelease()
        {
            // active 상태였으면, normal 상태로,               
            // deactive 상태엾으면, deactive 상태로.
            if (isActive) myAnimator.Normal();
            else myAnimator.Deactive();
            InvokeReleaseEvent();
        }
    }
}
