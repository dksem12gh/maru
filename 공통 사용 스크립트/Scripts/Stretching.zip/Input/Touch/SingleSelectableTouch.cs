using System.Collections.Generic;
using UnityEngine;

namespace DigitalMaru.Common
{
    /// <summary>
    /// 여러개의 터치 중, 하나만 선택을 할 수 있는 터치.
    /// 하나가 선택되면, 다른 터치들은 비활성화 된다.
    /// </summary>
    public class SingleSelectableTouch : Touch
    {
        [SerializeField] List<Touch> touchList = new List<Touch>();

        public override bool Pressed => PressedCount == 1;

        bool MultiplePressed => 1 < PressedCount;

        int PressedCount
        {
            get
            {
                int count = 0;
                foreach (var touch in touchList)
                {
                    if (touch.Pressed) count += 1;
                }
                return count;
            }
        }


        void OnEnable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent += OnPressed;
                touch.UpdateEvent += OnUpdated;
                touch.ReleaseEvent += OnRelease;
            }
        }

        void OnDisable()
        {
            foreach (var touch in touchList)
            {
                touch.PressedEvent -= OnPressed;
                touch.UpdateEvent -= OnUpdated;
                touch.ReleaseEvent -= OnRelease;
            }
        }
        public override void ResetTouch()
        {
            foreach (var touch in touchList)
                touch.ResetTouch();
        }

        public override void SetActive(bool active)
        {
            foreach(var touch in touchList)
                touch.SetActive(active);
        }

        public override void SetLock(bool isLock)
        {
            foreach (var touch in touchList)
                touch.SetLock(isLock);
        }

        public override void SetLock(bool isLock, int index)
        {
            int num = 0;
            foreach (var touch in touchList)
            {
                if(num == index)
                    touch.SetLock(isLock);
                num++;
            }
        }

        void OnPressed()
        {
            UpdateTouches();
            InvokePressedEvent();
        }

        void OnUpdated()
        {
            UpdateTouches();
            InvokeUpdateEvent();
        }

        void OnRelease()
        {
            UpdateTouches();
            InvokeReleaseEvent();
        }

        void UpdateTouches()
        {
            if(PressedCount == 0)
                EnableAllTouch();
            else
            {
                if (Pressed)
                    DisableOthers();                
            }            
        }

        void EnableAllTouch ()
        {
            foreach (var touch in touchList)
            {   
                touch.SetActive(true);
            }
        }

        void DisableOthers()
        {
            foreach (var touch in touchList)
            {
                if (touch.Pressed is false)
                {
                    touch.SetActive(false);
                }
            }
        }       
    }
}
