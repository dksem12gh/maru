using UnityEngine;

namespace DigitalMaru.Common
{
    public class PlayerTouch : SingleTouch
    {
        [SerializeField] private PlayerTouchAnimator myAnimator;

        Collider touchCollider;
        Collider GetCollider() => touchCollider ??= GetComponent<Collider>();

        public override void SetActive (bool active)
        {
            if (this.enabled == active) return;

            if(GetCollider() != null)
                GetCollider().enabled = active;
            if (active)
                myAnimator.Normal();
            else
                myAnimator.Deactive();
            base.SetActive(active);
        }
     
        protected override void Press()
        {
            myAnimator.Press();

            base.Press(); // event는 제일 마지막에 호출.
        }

        protected override void Release(bool notify)
        {
            myAnimator.Normal();
            base.Release(notify); // event는 제일 마지막에 호출.
        }
    }
}
