using UnityEngine;


namespace DigitalMaru.Common
{
    public class PlayerTouchAnimator : MonoBehaviour
    {
        [Header("Activate")]
        [SerializeField] private ParticleSystem efx;
        [SerializeField] private AudioSource pressAudioSource;
        [SerializeField] private Animator touchAnimator;

        [Header("DeActivate")]
        [SerializeField] private GameObject deActiveObject;

        readonly int STATE_HASH = Animator.StringToHash("state");

        private void Reset()
        {
            touchAnimator = GetComponent<Animator>();
        }

        public void Normal()
        {
            touchAnimator.SetInteger(STATE_HASH, 0);
            deActiveObject.SetActive(false);
        }

        public void Press()
        {
            efx.Play();
            pressAudioSource.Play();
            Hover();
        }

        public void Hover()
        {
            touchAnimator.SetInteger(STATE_HASH, 1);
            deActiveObject.SetActive(false);
        }

        public void Deactive()
        {
            touchAnimator.SetInteger(STATE_HASH, 2);
            deActiveObject.SetActive(true);
        }
    }
}
