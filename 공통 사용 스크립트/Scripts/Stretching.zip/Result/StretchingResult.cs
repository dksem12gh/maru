using UnityEngine;

namespace DigitalMaru.Common
{
    public abstract class StretchingResult : MonoBehaviour 
    {
        abstract public ResultData[] ToResultData();
    }
}
