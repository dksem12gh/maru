using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingTimeResult : StretchingResult
    {
        [SerializeField] private StretchingStopWatchTimer totalTimer;
        [SerializeField] private StretchingPlayerScore[] playerScores;

        public override ResultData[] ToResultData()
        {
            ResultData[] result = new ResultData[playerScores.Length];
            for (int i = 0; i < playerScores.Length; i++)
            {
                result[i] = playerScores[i].ToResultData();
                result[i].AllTimeSec = Mathf.FloorToInt(totalTimer.TotalTime);
            }
            return result;
        }
    }
}
