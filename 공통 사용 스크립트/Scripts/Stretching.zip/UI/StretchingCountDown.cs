using TMPro;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingCountDown : MonoBehaviour
    {
        [SerializeField] private AudioSource Sound;
        [SerializeField] private TextMeshProUGUI countText;

        private void Start()
        {
            Hide();
        }

        public void Show(int count)
        {
            countText.text = count.ToString();
            Show();
        }

        public void Show()
        {            
            gameObject.SetActive(true);
            Sound.Play();
        }

        public void Hide()
        {
            gameObject.SetActive(false);
        }
    }
}
