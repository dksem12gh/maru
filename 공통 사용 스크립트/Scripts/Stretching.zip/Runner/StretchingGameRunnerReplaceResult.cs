using System.Collections;
using UnityEngine;


namespace DigitalMaru.Common
{
    public class MaruGameRunnerReplaceResult : MaruGameRunner
    {
        [SerializeField] private MaruGameRunner runner;
        [SerializeField] private StretchingResult result;

        public override void Prepare()
        {
            runner.Prepare();
        }

        public override IEnumerator Run()
        {
            StartRunnerEvent.Invoke();
            yield return runner.Run();
            EndRunnerEvent.Invoke();
        }

        public override void Pause(bool pause)
        {
            runner.Pause(pause);
        }
        public override ResultData[] GetResultData() => result.ToResultData();
    }
}
