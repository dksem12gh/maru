using System.Collections;
using UnityEngine;


namespace DigitalMaru.Common
{
    public class TwoPlayerMaruGameRunner : MaruGameRunner
    {
        [Header("Players")]
        [SerializeField] private StretchingPlayer[] players;

        [SerializeField] private StretchingTotalTime totalTime;

        readonly GameSettingsBridge settings = new GameSettingsBridge();

        public override void Prepare()
        {
            foreach (var player in players)
                player.Prepare(settings);

            totalTime.Prepare(settings);
        }

        public override IEnumerator Run()
        {
            foreach (var player in players)
                player.Do();

            yield return new WaitUntil(() =>
            {
                var completed = false;

                if (totalTime.Sec <= 0)
                    completed = true;
                else                
                    completed = false;                

                /*foreach (var player in players)
                {
                    if (player.Completed is false) return false;
                    completed = true;
                }*/
                return completed;
            });
        }

        public override ResultData[] GetResultData()
        {
            ResultData[] result = new ResultData[players.Length];
            for (int i = 0; i < players.Length; i++)
            {
                result[i] = players[i].ToResultData();
            }
            return result;
        }

        public override void Pause(bool pause)
        {
            foreach (var player in players)
                player.Pause(pause);

            totalTime.Pause(pause);
        }
    }
}
