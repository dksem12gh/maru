using System.Collections;
using UnityEngine;
using UnityEngine.Events;


namespace DigitalMaru.Common
{
    public class StretchingGameManager : MultiDisplayTouchGameManager
    {
        [Header("Main Reference")]
        [SerializeField] private TitleWindowFactory titleWindowFactory;
        [SerializeField] private ResultWindowFactory resultWindowFactory;
        [SerializeField] private MaruGameRunner runner;


        [Header("GameObjects")]
        [SerializeField] private GameObject background;

        [Header("Events")]
        [SerializeField] private UnityEvent<bool> PauseEvent = new UnityEvent<bool>();

        bool DoingRun { get; set; } = false;

        private void Reset()
        {
            this.titleWindowFactory = GetComponent<TitleWindowFactory>();
            this.resultWindowFactory = GetComponent<ResultWindowFactory>();            
        }

        protected override IEnumerator DoInit()
        {
            background.SetActive(false);
            runner.Prepare();
            yield break;
        }

        protected override IEnumerator DoTitle()
        {
            yield return titleWindowFactory.CreateAndRemoveWithDelayed();            
            background.SetActive(true);
        }


        protected override IEnumerator DoRun()
        {
            // Pause 체크를 위한 값 세팅. 하드코딩으로 처리 하였음.
            DoingRun = true;
            yield return runner.Run();
            DoingRun = false;
        }

        protected override IEnumerator DoResult()
        {            
            resultWindowFactory.CreateAndShow(runner.GetResultData());
            yield break;
        }

        protected override void OnPause(bool pause)
        {
            if (DoingRun) runner.Pause(pause);
            PauseEvent?.Invoke(pause);
        }
    }
}
