using UnityEngine;


namespace DigitalMaru.Common
{
    public abstract class StretchingPoseListRule : StretchingRule
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingPose[] pose;

        [Header("Components")]
        [SerializeField] private GameObject CanvasRoot;

        protected bool IsPlaying { get; set; } = false;
        protected int SelectedLevel = 0;

        private void Start() 
        {
            if(CanvasRoot != null)
                CanvasRoot.SetActive(false);
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            SelectedLevel = Managers.GameLevel;

            for (int i = 0; i < pose.Length; i++)
            {
                if (i == SelectedLevel)
                {
                    pose[i].enabled = true;
                    pose[i].Prepare();                    
                }
                else
                {
                    pose[i].enabled = false;                    
                }
            }            
        }

        public override void Begin(in TouchPad touchPad)
        {
            if (IsPlaying) return;
            if (CanvasRoot != null)
                CanvasRoot.SetActive(true);
            IsPlaying = true;

            touchPad.SetLock(false);
            pose[SelectedLevel].Begin(touchPad);
            touchPad.TouchEvent += Touch;

            BeginHandle(touchPad);
            StartEvent.Invoke();
        }

        int step = 0;

        public override void Touch(TouchPad touchPad)
        {
            if (IsPlaying is false) return;
            if (touchPad.FailPressed)
            {
                FailedHandle(touchPad);
                FailedEvent.Invoke();
                return;
            }
            
            if (pose[SelectedLevel].CheckPose(touchPad))
            {                
                SuccessEvent.Invoke();                
                SuccessHandle(touchPad);
                step++;
            }/*
            else if(step >= 4)
            {
                step = 0;
                SuccessEvent.Invoke();
                SuccessHandle(touchPad);
            }*/
            else
            {
                FailedHandle(touchPad);
                FailedEvent.Invoke();
            }
        }

         void End(in TouchPad touchPad)
         {
            if (IsPlaying is false) return;

            IsPlaying = false;
            touchPad.ResetTouch();
            touchPad.SetLock(true);
            touchPad.TouchEvent -= Touch;

            CompletedHandle(touchPad);
            CompletedEvent.Invoke();
         }

        public override void Stop(in TouchPad touchPad)
        {
            if (IsPlaying is false) return;

            IsPlaying = false;
            touchPad.ResetTouch();
            touchPad.SetLock(true);
            touchPad.TouchEvent -= Touch;
        }

        protected virtual void BeginHandle(TouchPad touchPad) { }
        protected virtual void SuccessHandle (TouchPad touchPad)
        {
            NextPose(touchPad);
        }
        protected virtual void FailedHandle (TouchPad touchPad) { }
        protected virtual void CompletedHandle(TouchPad touchPad) { }

        protected void NextPose(TouchPad touchPad)
        {
            if (Completed) End(touchPad);
            else pose[SelectedLevel].Next(touchPad);
        }
    }    
}
