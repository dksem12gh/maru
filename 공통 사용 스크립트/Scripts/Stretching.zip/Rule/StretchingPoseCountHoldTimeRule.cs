using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseCountHoldTimeRule : StretchingPoseRule
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingPlayerCountScore playerScore;

        public override bool Completed
        {
            get
            {
                if (Settings.Infinite) return false;
                return Settings.GameCountGoal <= playerScore.Score;
            }
        }

        public override void Stop(in TouchPad touchPad)
        {
            throw new System.NotImplementedException();
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            playerScore.ScoreUp();
            NextPose(touchPad);
        }
    }

}
