using DigitalMaru.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public class StretchingPoseTimeAddRule : StretchingPoseRule
    {        
        [SerializeField] private StretchingPlayerTimeScore playerTimeScore;
        [SerializeField] private StretchingStopWatchTimer playerTimer;

        [Header("PoseTime Events")]
        [SerializeField] UnityEvent EnterPoseEvent = new UnityEvent();
        [SerializeField] UnityEvent LeavePoseEvent = new UnityEvent();
        
        [SerializeField] UnityEvent TimeImminentEvent = new UnityEvent();
        [SerializeField] UnityEvent TimeCountEvent = new UnityEvent();
        
        [SerializeField] float timeImminent = 10;
        [SerializeField] bool isTimeImminent = false;
        [SerializeField] float timeCount = 3;
        [SerializeField] bool isTimeCount = false;



        public override bool Completed
        {
            get
            {
                if (Settings.Infinite) return false;
                return Settings.GameTimeSecGoal <= playerTimeScore.Sec;
            }
        }

        bool entered = false;
        float enteredTime = 0;

        private void OnEnable()
        {
            StartEvent.AddListener(OnBegin);
            CompletedEvent.AddListener(OnEnd);
            SuccessEvent.AddListener(OnSuccess);
            FailedEvent.AddListener(OnFailed);
        }

        private void OnDisable()
        {
            StartEvent.RemoveListener(OnBegin);
            CompletedEvent.RemoveListener(OnEnd);
            SuccessEvent.RemoveListener(OnSuccess);
            FailedEvent.RemoveListener(OnFailed);
        }
        
        void OnBegin()
        {
            playerTimer.Begin();
        }

        void OnEnd()
        {
            playerTimer.Stop();
        }
        public override void Pause(bool pause)
        {
            base.Pause(pause);
            playerTimer.Pause(pause);
        }

        void OnSuccess ()
        {
            if(entered is false)
            {
                entered = true;
                enteredTime = Time.time;
                EnterPoseEvent.Invoke();
            }
            else
            {
                float a = playerTimeScore.Sec;
                playerTimeScore.AddTime(Time.time - enteredTime);
                enteredTime = Time.time;
                
                if(isTimeImminent is false)
                    CheckTimeImminent(timeImminent, OnTimeImminent);
                if(isTimeCount is false)
                    CheckTimeImminent(timeCount, CountDownCheck);

            }
        }


        void CheckTimeImminent(float targettime, Action action)
        {
            float t = Managers.GameTime*60;
            float compartime = t - playerTimeScore.Sec;
            if(targettime == (int)compartime)
            {
                action.Invoke();     
            }
        }

        void OnTimeImminent()
        {
            isTimeImminent = true;
            TimeImminentEvent.Invoke();
        }

        void CountDownCheck()
        {
            if(timeCount <=1)
                isTimeCount = true;

            timeCount--;
            OnCountDown();
        }

        void OnCountDown()
        {
            TimeCountEvent.Invoke();
        }

        void OnFailed()
        {
            if (entered)
            {
                playerTimeScore.AddTime(Time.time - enteredTime);
                entered = false;
                enteredTime = Time.time;
                LeavePoseEvent.Invoke();
            }
        }
    }
}