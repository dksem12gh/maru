using System.Collections.Generic;
using UnityEngine;


namespace DigitalMaru.Common
{
    public class StretchingSequenceRule : StretchingRule
    {
        [Header("Components")]
        [SerializeField] private GameObject CanvasRoot;
        [SerializeField] private StretchingStopWatchTimer playerTimer;
        [SerializeField] private StretchingPlayerScore playerScore;
        [SerializeField] private List<StretchingPoseRuleProcessor> processors = new();

        // 실패 했을 때, 처음부터 돌아 갈지 말지, 정하는 플래그.
        [SerializeField] private bool backToFirst = true;

        bool completed = false;
        public override bool Completed => completed;
        protected bool IsPlaying { get; set; } = false;

        readonly Queue<IStretchingPoseRuleProcessor> queue = new ();

        IStretchingPoseRuleProcessor Current { get; set; }
        bool CanMoveNext => 0 < queue.Count;

        void Start()
        {
            if (CanvasRoot != null)
                CanvasRoot.SetActive(false);
        }

        void SetProcessor(IStretchingPoseRuleProcessor processor, TouchPad touchPad)
        {
            if (Current is not null)
            {
                Current = null;
            }
            Current = processor;
            Current.Begin(touchPad);
        }
        void EqneueProcessors()
        {
            queue.Clear();
            foreach (var processor in processors)
                queue.Enqueue(processor);
        }
        public override void Pause(bool pause)
        {
            if (IsPlaying is false) return;
            playerTimer.Pause(pause);
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            foreach (var processor in processors) 
                processor.Prepare(settings);
            EqneueProcessors();
            playerScore.Prepare(settings);         
        }
            
        public override void Begin(in TouchPad touchPad)
        {
            if (IsPlaying) return;

            if (CanvasRoot != null)
                CanvasRoot.SetActive(true);

            touchPad.TouchEvent += Touch;

            IsPlaying = true;
            playerTimer.Begin();
            SetProcessor(queue.Dequeue(), touchPad);
        }

        public override void Stop(in TouchPad touchPad)
        {
            if (IsPlaying is false) return;

            IsPlaying = false;
            playerTimer.Stop();
            touchPad.TouchEvent -= Touch;
        }

        public override void Touch(TouchPad touchPad)
        {
            if (IsPlaying is false) return;
            var result = Current.Touch(touchPad);
            ResultHandle(result, touchPad);
        }


        protected virtual void ResultHandle(bool result, TouchPad touchPad)
        {
            if (Current.Completed)
            {
                if (CanMoveNext)
                    Next(touchPad);
                else
                    Complete(touchPad);
            }
            else if (result is false)
            {
                if(backToFirst)
                    BackFirst(touchPad);
            }
           
        }

        void Complete(TouchPad touchPad)
        {
            IsPlaying = false;
            playerTimer.Stop();
            completed = true;
            touchPad.TouchEvent -= Touch;
            touchPad.SetLock(true);
            CompletedEvent.Invoke();
        }

        void Next(TouchPad touchPad)
        {
            SetProcessor(queue.Dequeue(), touchPad);
        } 
        
        void BackFirst(TouchPad touchPad)
        {
            // 2개 이상일 때, 처리 한다.
            if (processors.Count <= 1) return;

            EqneueProcessors();
            Next(touchPad);
        }
    }
}
