using System;
using UnityEngine.Assertions;

namespace DigitalMaru.Common
{
#if UNITY_EDITOR

    using UnityEditor;
    using UnityEngine;
    using UnityEngine.UIElements;



    [CustomPropertyDrawer(typeof(StretchingPoseValue))]
    public class StretchingPoseValuePropertyDrawer : PropertyDrawer
    {
        public override VisualElement CreatePropertyGUI(SerializedProperty property)
        {
            var root = new GroupBox();            
            root.style.borderBottomWidth = 0.5f;
            root.style.borderBottomColor = new StyleColor(Color.white);
            root.Add(CreateValueElement(property));
            return root;
        }

        VisualElement CreateValueElement(SerializedProperty property)
        {   
            var root = new VisualElement();                  
            // 입력 최대 갯수는 4개까지..
            // 07.04 rand burpee까지 버튼 수 일단 8까지 - 버피는 키오스크 오고 테스트후 수정
            for(int i = 0; i < 10; i++)
            {
                root.Add(CreateValueItemElement(i, property));
            }
            return root;

            VisualElement CreateValueItemElement(int index, SerializedProperty property)
            {
                var valueProperty = property.FindPropertyRelative("value");
                var poseValue = new StretchingPoseValue();
                poseValue.value = valueProperty.intValue;

                var toggle = new Toggle(index.ToString());
                toggle.value = poseValue.Contain(index);
                toggle.RegisterValueChangedCallback(newEvent =>
                {
                    var valueProperty = property.FindPropertyRelative("value");
                    var poseValue = new StretchingPoseValue();
                    poseValue.value = valueProperty.intValue;

                    if (newEvent.newValue)
                        poseValue.Add(index);
                    else
                        poseValue.Remove(index);
                    valueProperty.intValue = poseValue.value;
                    property.serializedObject.ApplyModifiedProperties();
                });
                return toggle;
            }
        }

    }
#endif

    [Serializable]
    public struct StretchingPoseValue
    {
        public int value;
        public StretchingPoseValue(params int[] indexes)
        {
            value = 0;
            if (null != indexes)
                AddArray(indexes);
        }

        public void Add(int index)
        {
            if(Contain(index) is false)
                value |= (1 << index);
        }

        public void AddArray(params int[] indexes)
        {
            Assert.IsNotNull(indexes);

            foreach (var index in indexes)
                Add(index);
        }

        public void Remove(int index)
        {
            if (Contain(index))
            {
                value &= ~(1 << index);
            }
        }

        public bool Contain(int index)
        {
            Assert.IsTrue(0 <= index);

            // start from 1. 
            var wantValue = 1 << index;
            return (value & wantValue) == wantValue;
        }
    }
}
