using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace DigitalMaru.Common
{
    public abstract class StretchingPoseDataProvider : ScriptableObject
    {
        public abstract List<StretchingPoseValue> Provide();
    }
}
