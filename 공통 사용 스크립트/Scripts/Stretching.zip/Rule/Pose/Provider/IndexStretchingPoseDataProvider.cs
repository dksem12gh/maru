using System.Collections.Generic;
using UnityEngine;

namespace DigitalMaru.Common
{
    [CreateAssetMenu(menuName = "DigitalMaru/Stretching/IndexStretchingPoseDataProvider", fileName = "IndexStretchingPoseDataProvider", order = 0)]
    public class IndexStretchingPoseDataProvider : StretchingPoseDataProvider
    {
        [SerializeField] List<StretchingPoseValue> Order = new List<StretchingPoseValue>();

        public override List<StretchingPoseValue> Provide() => Order;
    }
}
