using UnityEngine;

namespace DigitalMaru.Common
{
    public abstract class StretchingPose : MonoBehaviour
    {
        abstract public bool CanMoveNext { get; }
        abstract public void Prepare();
        abstract public bool CheckPose(in TouchPad touchPad);
        abstract public void Begin(in TouchPad touchPad);       
        abstract public void Next(in TouchPad touchPad);
    }
}
