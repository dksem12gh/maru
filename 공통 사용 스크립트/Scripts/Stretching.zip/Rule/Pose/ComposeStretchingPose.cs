using System.Collections.Generic;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class ComposeStretchingPose : StretchingPose
    {
        [SerializeField] StretchingPoseDataProvider provider;

        readonly Queue<StretchingPoseValue> queue = new();

        protected StretchingPoseValue CurrentPose => queue.Peek();

        protected void Enqueue(StretchingPoseValue pose) => queue.Enqueue(pose);
        protected void Enqueue(params int[] indexes)
        {
            StretchingPoseValue pose = new StretchingPoseValue();
            pose.AddArray(indexes);
            Enqueue(pose);
        }
        protected void Enqueue(in List<StretchingPoseValue> array)
        {
            foreach (var poseType in array)
                Enqueue(poseType);
        }
        protected int Count => queue.Count;

        protected void Clear() => queue.Clear();
        protected StretchingPoseValue Dequeue() => queue.Dequeue();


        public override bool CanMoveNext => 1 < Count;

        public override void Prepare()
        {
            Clear();
            foreach (var data in provider.Provide())
                Enqueue(data);
        }

        public override void Begin(in TouchPad touchPad)
        {
            UpdateTouchPad(CurrentPose, touchPad);
        }

        public override void Next(in TouchPad touchPad)
        {
            if (Count <= 1) return;

            var next = Dequeue();
            Enqueue(next);
            UpdateTouchPad(CurrentPose, touchPad);
        }

        public override bool CheckPose(in TouchPad touchPad)
        {
            var current = CurrentPose;
            for(int i = 0; i < touchPad.Len; i++)
            {
                if (current.Contain(i) is false) continue;                
                if (touchPad.GetPressed(i) is false) return false;                
            }
            return true;
        }

        static void UpdateTouchPad(StretchingPoseValue poseType, in TouchPad touchPad)
        {
            for(int i = 0; i < touchPad.Len; i++)
            {
                touchPad.TryGetTouch(i, out var touch);
                touch.SetActive(poseType.Contain(i));
            }
        }
    }
}
