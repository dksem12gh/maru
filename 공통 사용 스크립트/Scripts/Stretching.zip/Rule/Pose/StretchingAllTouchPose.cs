using DigitalMaru.Common;

public class StretchingAllTouchPose : StretchingPose
{
    public override void Begin(in TouchPad touchPad)
    {
        touchPad.SetActive(true);
    }

    public override bool CanMoveNext => false;

    public override bool CheckPose(in TouchPad touchPad)
    {
        return !touchPad.FailPressed && touchPad.AllPressed;
    }

    public override void Next(in TouchPad touchPad)
    {
    }

    public override void Prepare()
    {
    }
}
