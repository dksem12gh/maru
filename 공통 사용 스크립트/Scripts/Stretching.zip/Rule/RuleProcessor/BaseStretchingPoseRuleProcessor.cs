using UnityEngine;

namespace DigitalMaru.Common
{
    public abstract class BaseStretchingPoseRuleProcessor : StretchingPoseRuleProcessor
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingPose pose;

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            pose.Prepare();
        }

        public override void Begin(TouchPad touchPad)
        {
            pose.Begin(touchPad);
        }

        public override bool Touch(TouchPad touchPad)
        {
            if (touchPad.FailPressed)
            {
                FailedHandle();
                return false;
            }

            if (pose.CheckPose(touchPad))
            {
                SuccessHandle();
                return true;
            }
            else
            {
                FailedHandle();
                return false;
            }
        }
        abstract public void SuccessHandle();
        abstract public void FailedHandle();
    }
}