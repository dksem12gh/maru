using UnityEngine;


namespace DigitalMaru.Common
{
    public abstract class StretchingPoseRuleProcessor : MonoBehaviour, IStretchingPoseRuleProcessor
    {
        GameSettingsBridge settings = null;
        protected GameSettingsBridge Settings => settings ?? new GameSettingsBridge();
        abstract public bool Completed { get; }
        public virtual void Prepare(in GameSettingsBridge settings)
        {
            this.settings = settings;
        }

        abstract public void Begin(TouchPad touchPad);
        abstract public bool Touch(TouchPad touchPad);
    }
}
