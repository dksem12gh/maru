using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public interface IStretchingPoseRuleProcessor
    {        
        bool Completed { get; }
        void Prepare(in GameSettingsBridge settings);
        void Begin(TouchPad touchPad);
        bool Touch(TouchPad touchPad);
    }
}
