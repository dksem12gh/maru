using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseTimeRuleProcessor : BaseStretchingPoseRuleProcessor
    {
        [SerializeField] StretchingPlayerTimeScore playerTimeScore;

        [Space]
        [SerializeField] bool overrideTime = false;
        [SerializeField] float overrideTimeSec = 5f;
        [SerializeField] StretchingPoseIncrementalTimer timer;
        public override bool Completed => timer.Completed;

        void OnEnable()
        {
            timer.UpdateEvent.AddListener(OnUpdate);
        }

        void OnDisable()
        {
            timer.UpdateEvent.RemoveListener(OnUpdate);
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            if (overrideTime) timer.WantTimeSec = overrideTimeSec;
            else timer.WantTimeSec = settings.GameTimeSecGoal;
        }

        public override void Begin(TouchPad touchPad)
        {
            base.Begin(touchPad);            
            // 소숫점 계산 때문에, 처음에 소숫점 만큼 보정해줘야 함.
            timer.ResetTime(playerTimeScore.Sec);
        }

        public override void SuccessHandle()
        {
            timer.Enter();
        }
        public override void FailedHandle()
        {
            timer.Leave();
        }

        void OnUpdate(float dt)
        {
            playerTimeScore.AddTime(dt);
        }
    }
}
