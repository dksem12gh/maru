using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseCountTimeRuleProcessor : BaseStretchingPoseRuleProcessor
    {
        [SerializeField] StretchingPlayerCountTimeScore playerTimeScore;

        [Space]
        [SerializeField] bool overrideTime = false;
        [SerializeField] float overrideTimeSec = 5f;
        [SerializeField] StretchingPoseIncrementalTimer timer;
        public override bool Completed => timer.Completed;

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            timer.WantTimeSec = 3;
        }

        public override void Begin(TouchPad touchPad)
        {
            base.Begin(touchPad);
            // 소숫점 계산 때문에, 처음에 소숫점 만큼 보정해줘야 함.
            timer.ResetTime(playerTimeScore.Sec);
        }

        public override void SuccessHandle()
        {
            timer.Enter();
        }
        public override void FailedHandle()
        {
            timer.Leave();
        }
    }
}
