using UnityEngine;


namespace DigitalMaru.Common
{
    public class StretchingPoseReadyRuleProcessor : BaseStretchingPoseRuleProcessor
    {
        [SerializeField] private float keepTime = 3f;
        [Space]
        [SerializeField] StretchingPoseReleaseTimer timer;
        public override bool Completed => timer.Completed;

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);            
            timer.WantTimeSec = keepTime;
        }

        public override void SuccessHandle()
        {
            timer.Enter();  
        }

        public override void FailedHandle()
        {
            timer.Leave();
        }
    }
}
