using System.Collections.Generic;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseSwitchLoopProcessorWithTime : StretchingPoseRuleProcessor
    {
        [SerializeField] StretchingPlayerTimeScore playerTimeScore;
        [SerializeField] private List<StretchingPoseRuleProcessor> processors = new();

        public override bool Completed
        {
            get
            {
                if (Settings.Infinite) return false;
                return Settings.GameTimeSecGoal <= playerTimeScore.Sec;
            }
        }
        readonly Queue<IStretchingPoseRuleProcessor> queue = new();
        IStretchingPoseRuleProcessor Current { get; set; }
        void SetProcessor(IStretchingPoseRuleProcessor processor, TouchPad touchPad)
        {
            if (Current is not null)
            {
                Current = null;
            }
            Current = processor;
            Current.Begin(touchPad);
        }

        void EqneueProcessors()
        {
            queue.Clear();
            foreach (var processor in processors)
                queue.Enqueue(processor);
        }

        void Next(TouchPad touchPad)
        {
            // 현재 processor는 맨 마지막으로 넣는다.
            if(Current is not null)
                queue.Enqueue(Current);
            SetProcessor(queue.Dequeue(), touchPad);
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            foreach(var p in processors)
                p.Prepare(settings);
        }

        public override void Begin(TouchPad touchPad)
        {
            EqneueProcessors();
            SetProcessor(queue.Dequeue(), touchPad);
            Current.Begin(touchPad);
        }

        public override bool Touch(TouchPad touchPad)
        {
            var result = Current.Touch(touchPad);
            if (Completed) return true;

            if(result && Current.Completed)
            {
                Next(touchPad);
            }
            return result;
        }
    }
}
