using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseCountRule : StretchingPoseRule
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingPlayerCountScore playerScore;
        [SerializeField] StretchingStopWatchTimer timer;

        public override bool Completed
        {
            get
            {
                /*if (Settings.Infinite)*/ return false;
                /*return Settings.GameCountGoal <= playerScore.Score;*/
            }
        }

        private void OnEnable()
        {
            StartEvent.AddListener(OnBegin);
            CompletedEvent.AddListener(OnEnd);            
        }
        private void OnDisable()
        {
            StartEvent.RemoveListener(OnBegin);
            CompletedEvent.RemoveListener(OnEnd);            
        }

        void OnBegin()
        {
            timer.Begin();
        }

        void OnEnd()
        {
            timer.Stop();
        }

        public override void Pause(bool pause)
        {
            base.Pause(pause);
            timer.Pause(pause);
        }

        public override void Stop(in TouchPad touchPad)
        {
            throw new System.NotImplementedException();
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            playerScore.ScoreUp();
            NextPose(touchPad);
        }
    }

}
