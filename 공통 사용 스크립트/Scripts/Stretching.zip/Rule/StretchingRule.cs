using UnityEngine;
using UnityEngine.Events;


namespace DigitalMaru.Common
{
    public abstract class StretchingRule : MonoBehaviour
    {
        [Header("Events")]
        public UnityEvent SuccessEvent = new UnityEvent();
        public UnityEvent FailedEvent = new UnityEvent();
        public UnityEvent StartEvent = new UnityEvent();
        public UnityEvent CompletedEvent = new UnityEvent();

        GameSettingsBridge settings = null;
        protected GameSettingsBridge Settings => settings ?? new GameSettingsBridge();
        abstract public bool Completed { get; }
        public virtual void Prepare(in GameSettingsBridge settings)
        {
            this.settings = settings;
        }
        abstract public void Begin(in TouchPad touchPad);        
        abstract public void Stop(in TouchPad touchPad);
        abstract public void Touch(TouchPad touchPad);
        virtual public void Pause(bool pause) { }
    }
}
