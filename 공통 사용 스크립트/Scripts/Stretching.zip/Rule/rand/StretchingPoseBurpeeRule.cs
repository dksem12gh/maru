using System.Collections;
using UnityEngine;


namespace DigitalMaru.Common
{
    public class StretchingPoseBurpeeRule : StretchingRule
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingPose pose;
        [SerializeField] private StretchingPlayerCountScore playerScore;
        [SerializeField] GameObject[] txtObj;
        [SerializeField] BoxCollider jumpBlockCol;        

        [Header("Components")]
        [SerializeField] private GameObject CanvasRoot;
        [SerializeField] StretchingStopWatchTimer timer;

        [Header("MaxSuccessCount")]//몇동작이 한세트인지
        [SerializeField] private int successMaxCount;

        int curCount;

        public override bool Completed
        {
            get
            {
                //return false;
                return Settings.GameCountGoal <= playerScore.Score;
            }
        }

        protected bool IsPlaying { get; set; } = false;

        private void OnEnable()
        {
            StartEvent.AddListener(OnBegin);
            CompletedEvent.AddListener(OnEnd);
        }

        private void OnDisable()
        {
            StartEvent.RemoveListener(OnBegin);
            CompletedEvent.RemoveListener(OnEnd);
        }

        private void Start()
        {
            if(CanvasRoot != null)
                CanvasRoot.SetActive(false);
        }

        void OnBegin()
        {
            StartCoroutine(StartDelay());
        }

        IEnumerator StartDelay()
        {
            yield return YieldInstructionCache.WaitForSeconds(3.5f);
            timer.Begin();
        }

        void OnEnd()
        {
            timer.Stop();
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            pose.Prepare();
        }

        public override void Begin(in TouchPad touchPad)
        {
            if (IsPlaying) return;
            if (CanvasRoot != null)
                CanvasRoot.SetActive(true);
            IsPlaying = true;

            touchPad.SetLock(false);
            pose.Begin(touchPad);
            touchPad.TouchEvent += Touch;

            BeginHandle(touchPad);
            StartEvent.Invoke();

            touchPad.SetLock(true, 4);
            touchPad.SetLock(true, 5);
        }

        public override void Touch(TouchPad touchPad)
        {
            if (IsPlaying is false) return;
            if (touchPad.FailPressed)
            {
                FailedHandle(touchPad);
                FailedEvent.Invoke();
                return;
            }
            if (pose.CheckPose(touchPad))
            {                
                SuccessEvent.Invoke();                
                SuccessHandle(touchPad);
            }
            else
            {
                FailedHandle(touchPad);
                FailedEvent.Invoke();
            }
        }

         void End(in TouchPad touchPad)
         {
            if (IsPlaying is false) return;

            IsPlaying = false;
            touchPad.ResetTouch();
            touchPad.SetLock(true);
            touchPad.TouchEvent -= Touch;

            CompletedHandle(touchPad);
            CompletedEvent.Invoke();
         }

        public override void Stop(in TouchPad touchPad)
        {
            if (IsPlaying is false) return;

            IsPlaying = false;
            touchPad.ResetTouch();
            touchPad.SetLock(true);
            touchPad.TouchEvent -= Touch;
        }
        public override void Pause(bool pause)
        {
            base.Pause(pause);
            timer.Pause(pause);
        }

        protected virtual void BeginHandle(TouchPad touchPad) { }
        protected virtual void ReleaseHandle(TouchPad touchPad) { }
        protected virtual void SuccessHandle (TouchPad touchPad)
        {            
            touchPad.SetLock(true, 4);
            touchPad.SetLock(true, 5);

            curCount++;
            if (curCount == 4)
            {
                jumpBlockCol.enabled = true;

                txtObj[0].SetActive(false);
                txtObj[1].SetActive(true);                
                touchPad.SetLock(false, 5);
            }
            else
            {
                txtObj[0].SetActive(true);
                txtObj[1].SetActive(false);
            }
            if (curCount % successMaxCount == 0)
            {
                playerScore.ScoreUp();
                curCount = 0;
            }

            NextPose(touchPad);
        }
        protected virtual void FailedHandle (TouchPad touchPad) { }
        protected virtual void CompletedHandle(TouchPad touchPad) { }

        protected void NextPose(TouchPad touchPad)
        {
            //if (Completed) End(touchPad);
            /*else*/ pose.Next(touchPad);
        }
    }    
}
