using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseCountNextRuleRand : StretchingPoseRule
    {
        [SerializeField] private int maxBtnCount;
        [Header("Main Reference")]
        [SerializeField] private StretchingPlayerCountScore playerScore;        
        [SerializeField] MultipleTouchPad multiPad;

        int count = 0;

        public override bool Completed
        {
            get
            {
                /*if (Settings.Infinite) */return false;
                /*return Settings.GameCountGoal <= playerScore.Score;*/
            }
        }

        public override void Stop(in TouchPad touchPad)
        {
            throw new System.NotImplementedException();
        }

        protected override void ReleaseHandle(TouchPad touchPad)
        {
            base.ReleaseHandle(touchPad);
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            count++;
            
            if (count % maxBtnCount == 0)
            {
                playerScore.ScoreUp();
                count = 0;
            }

            NextPose(touchPad);
        }
    }

}
