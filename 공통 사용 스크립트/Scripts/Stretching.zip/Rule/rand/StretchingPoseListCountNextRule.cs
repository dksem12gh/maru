using UnityEngine;

namespace DigitalMaru.Common
{
    //플레이어 키 맞출때 눌러야할 발판 수가 달라지는 경우
    public class StretchingPoseListCountNextRule : StretchingPoseListRule
    {
        [SerializeField] private int maxBtnCount;
        [Header("Main Reference")]
        [SerializeField] private StretchingPlayerCountScore playerScore;        
        [SerializeField] MultipleTouchPad[] multiPad;
        [SerializeField] GameObject[] ruleObjPad;

        int count = 0;
        
        public override bool Completed
        {
            get
            {
                return false;                
            }
        }

        public override void Stop(in TouchPad touchPad)
        {
            throw new System.NotImplementedException();
        }

        public override void Begin(in TouchPad touchPad)
        {
            base.Begin(touchPad);

            switch(SelectedLevel)
            {
                case 0:
                    maxBtnCount = 19;                    
                    break;
                case 1:
                    maxBtnCount = 15;
                    break;
                case 2:
                    maxBtnCount = 11;
                    break;
            }

            for (int i = 0; i<multiPad.Length; i++)
            {
                if(i == SelectedLevel)
                {
                    multiPad[i].enabled = true;
                    ruleObjPad[i].SetActive(true);
                }
                else
                {
                    multiPad[i].enabled = false;
                    ruleObjPad[i].SetActive(false);
                }
            }
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            count++;
            
            if (count % maxBtnCount == 0)
            {
                playerScore.ScoreUp();
                count = 0;
            }

            NextPose(touchPad);
        }
    }

}
