using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPoseSupineLegRaise : StretchingPoseRule
    {
        [SerializeField] private int maxBtnCount;
        [Header("Main Reference")]
        [SerializeField] private StretchingPlayerCountScore playerScore;        
        [SerializeField] MultipleTouchPad multiPad;
        [SerializeField] GameObject blockPad;

        int count = 0;

        public override bool Completed
        {
            get
            {
                return false;                
            }
        }

        public override void Stop(in TouchPad touchPad)
        {
            throw new System.NotImplementedException();
        }

        protected override void ReleaseHandle(TouchPad touchPad)
        {
            base.ReleaseHandle(touchPad);
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            count++;
            
            if(count == 1)
            {
                blockPad.SetActive(true);
            }
            else
            {
                blockPad.SetActive(false);
            }

            if (count % maxBtnCount == 0)
            {
                playerScore.ScoreUp();
                count = 0;
            }

            NextPose(touchPad);
        }
    }

}
