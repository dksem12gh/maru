using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public class StretchingPoseTimeRule : StretchingPoseRule
    {
        [Space]
        [SerializeField] private StretchingStopWatchTimer playerTimer;
        [SerializeField] private StretchingPlayerTimeScore playerTimeScore;

        [Header("PoseTime Events")]
        [SerializeField] UnityEvent EnterPoseEvent = new UnityEvent();
        [SerializeField] UnityEvent LeavePoseEvent = new UnityEvent();

        public override bool Completed
        {
            get
            {
                if (Settings.Infinite) return false;
                return Settings.GameTimeSecGoal <= playerTimeScore.Sec;
            }
        }

        bool entered = false;
        float enteredTime = 0;

        private void OnEnable()
        {
            StartEvent.AddListener(OnBegin);
            FailedEvent.AddListener(OnFailed);
            CompletedEvent.AddListener(OnEnd);
        }

        private void OnDisable()
        {
            StartEvent.RemoveListener(OnBegin);
            FailedEvent.RemoveListener(OnFailed);
            CompletedEvent.RemoveListener(OnEnd);
        }
        

        void OnBegin()
        {
            playerTimer.Begin();
        }

        void OnEnd()
        {
            playerTimer.Stop();
        }

        public override void Pause(bool pause)
        {
            base.Pause(pause);
            playerTimer.Pause(pause);
        }

        protected override void SuccessHandle(TouchPad touchPad)
        {
            if (entered is false)
            {
                entered = true;
                enteredTime = Time.time;
                EnterPoseEvent.Invoke();
            }
            else
            {
                playerTimeScore.AddTime(Time.time - enteredTime);
                enteredTime = Time.time;
            }
            NextPose(touchPad);
        }

        void OnFailed()
        {
            if (entered)
            {
                playerTimeScore.AddTime(Time.time - enteredTime);
                entered = false;
                enteredTime = Time.time;
                LeavePoseEvent.Invoke();
            }
        }
    }
}
