using System;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    /// <summary>
    /// 이 클래스는 터치를 누르면 초기화되고, 터치를 놓을 때마다 다시 초기화됨.
    /// </summary>
    [Serializable]
    public class StretchingPoseReleaseTimer
    {
        [SerializeField] private float wantTimeSec = 3;

        [Header("Events")]
        [SerializeField] UnityEvent EnterEvent;
        [SerializeField] UnityEvent<float> UpdateEvent;
        [SerializeField] UnityEvent LeaveEvent;
        [SerializeField] StretchingCountDownTimer countDownTimer;
        
        bool entered = false;
        float enteredOldTime = 0f;
        float CurrentTime => Time.time;

        bool Infinite => wantTimeSec < 0;
        
        public bool Completed
        {
            get
            {
                if (Infinite) return false;
                return wantTimeSec <= TotalTime;
            }
        }

        public float TotalTime { get; private set; } = 0f;
        public float WantTimeSec { get => wantTimeSec; set => wantTimeSec = value; }


        public void Enter()
        {
            if (entered is false)
            {
                TotalTime = 0;
                entered = true;
                enteredOldTime = CurrentTime;                                
                
                CountDownNotify();
                EnterEvent.Invoke();
            }
            else
            {
                var dt = CurrentTime - enteredOldTime;
                enteredOldTime = CurrentTime;
                TotalTime += dt;

                CountDownNotify();
                UpdateEvent.Invoke(dt);
            }
        }

        public void Leave()
        {
            if (entered)
            {
                entered = false;           
                TotalTime = 0;
                LeaveEvent.Invoke();
                countDownTimer.Reset();
            }
        }

        void CountDownNotify()
        {
            float diff = wantTimeSec - TotalTime;
            countDownTimer.CheckAndNotify(diff);
            if (Completed)
                countDownTimer.Complete();
        }
    }
}
