using UnityEngine;


namespace DigitalMaru.Common
{
    /// <summary>
    /// 제한시간에 맞춰서 사운드 호출.
    /// </summary>
    public class StretchingTimeLimitOnceSoundPlayer : MonoBehaviour
    {
        [SerializeField] private StretchingPlayerTimeScore target;
        [SerializeField] private AudioSource Sound;
        [SerializeField] private int LimitTime = 10;

        bool listened = false;

        void ListenEvent()
        {
            if (listened is false)
            {
                target.ChangedTimeScoreEvent.AddListener(CheckAndPlay);
                listened = true;
            }
        }

        void UnListenEvent()
        {
            if (listened)
            {
                target.ChangedTimeScoreEvent.RemoveListener(CheckAndPlay);
                listened = false;
            }
        }

        void OnEnable()
        {
            ListenEvent();
        }

        private void OnDisable()
        {
            UnListenEvent();
        }

        public void CheckAndPlay(float _)
        {
            if (CanPlaySound())
            {
                Play();
                // 한번만 플레이 하기 때문에, 이벤트를 끊는다.
                UnListenEvent();
            }
        }

        bool CanPlaySound()
        {
            var diff = target.GoalInt - target.SecInt;
            return diff == LimitTime;
        }

        void Play()
        {
            Sound.Play();
        }
    }
}
