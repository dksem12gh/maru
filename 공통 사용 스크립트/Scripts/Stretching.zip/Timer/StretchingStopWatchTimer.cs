using System.Collections;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingStopWatchTimer : MonoBehaviour
    {

        public float TotalTime => time;
        public float DeltaTime
        {
            get;
            private set;
        } = 0;

        float time = 0f;
        bool play = false;
        bool pause = false;
        
        Coroutine timerRoutine = null;

        public void Begin()
        {
            if (play) return;

            time = 0f;
            DeltaTime = 0f;
            timerRoutine = StartCoroutine(TimerRoutine());
        }

        public void Pause(bool pause)
        {
            this.pause = pause;
        }

        public void Stop()
        {
            if(null != timerRoutine)
            {
                StopCoroutine(timerRoutine);
                timerRoutine = null;
                play = false;
                DeltaTime = 0;
            }
        }

        IEnumerator TimerRoutine()
        {
            play = true;
            time = 0f;
            while(play)
            {
                yield return YieldInstructionCache.WaitForFixedUpdate;
                DeltaTime = Time.fixedDeltaTime;
                time += DeltaTime;
                if (pause)
                    yield return YieldInstructionCache.WaitUntil(() => !pause);
            }
        }
    }
}
