using System;
using UnityEngine;
using UnityEngine.Events;


namespace DigitalMaru.Common
{
    /// <summary>
    ///  이 클래스는 터치를 누르면 시간이 지남에 따라 유지됨.
    /// </summary>
    [Serializable]
    public class StretchingPoseIncrementalTimer
    {
        [SerializeField] private float wantTimeSec = 3;
        [Header("Events")]
        [SerializeField] public UnityEvent EnterEvent;
        [SerializeField] public UnityEvent<float> UpdateEvent;
        [SerializeField] public UnityEvent LeaveEvent;
        [SerializeField] StretchingCountDownTimer countDownTimer;

        bool entered = false;
        float enteredOldTime = 0f;
        float CurrentTime => Time.time;

        bool Infinite => wantTimeSec < 0;

        public bool Completed 
        {
            get
            {
                if (Infinite) return false;
                return wantTimeSec <= TotalTime;
            }            
        }

        public float TotalTime { get; private set; } = 0f;

        public float WantTimeSec { get => wantTimeSec; set => wantTimeSec = value; }        
 
        public void Enter()
        {            
            if (entered is false)
            { 
                entered = true;
                enteredOldTime = CurrentTime;
                EnterEvent.Invoke();
            }
            else
            {
               UpdateTime();
            }
        }

        public void Leave()
        {
            if (entered)
            {
                entered = false;
                UpdateTime();
                LeaveEvent.Invoke();
            }
        }

        void UpdateTime ()
        {
            var dt = CurrentTime - enteredOldTime;
            enteredOldTime = CurrentTime;
            TotalTime += dt;
            CountDownNotify();
            UpdateEvent.Invoke(dt);
            if (Completed)
            {
                countDownTimer.Complete();
            }
        }

        void CountDownNotify()
        {
            float diff = wantTimeSec - TotalTime;
            countDownTimer.CheckAndNotify(diff);
        }

        public void ResetTime (float time)
        {
            // TotalTIme은 WantTime 보다 클 수가 있음.
            // TotalTIme을 0으로 초기화하면, 미묘한 오차로 인해,
            // 다음 계산할 때, 시간이 맞지가 않음.
            var diff = time - Mathf.FloorToInt(time);
            diff = Mathf.Max(0, diff);            
            TotalTime = diff;
            entered = false;
        }
    }
}
