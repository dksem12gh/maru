using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    [System.Serializable]
    public class StretchingCountDownTimer
    {
        [SerializeField] int MinTimeSec = 0;
        [SerializeField] int MaxTimeSec = 3;
        [Header("Events")]
        [SerializeField] private UnityEvent<int> CountDownEvent = new UnityEvent<int>();
        [SerializeField] private UnityEvent CompletedEvent = new UnityEvent();

        readonly HashSet<int> RecordNotified = new HashSet<int>();

        public void Reset()
        {
            RecordNotified.Clear();
        }

        bool BetweenStartAndEnd(int timeSec)
        {
            return MinTimeSec <= timeSec && timeSec <= MaxTimeSec;
        }

        int ConverCount(int timeSec)
        {            
            var count = timeSec - MinTimeSec;
            return count;
        }

        public void CheckAndNotify (float time)
        {
            var timeInt =  Mathf.CeilToInt(time);
            if (BetweenStartAndEnd(timeInt))
            {
                InvokeEvent(ConverCount(timeInt));
            }
        }

        public void Complete()
        {
            Reset();
            CompletedEvent?.Invoke();
        }

        /// <summary>
        /// 같은 시간대의 이벤트는 한번만 호출한다.
        /// </summary>
        /// <param name="count"></param>
        void InvokeEvent (int count)
        {
            if (RecordNotified.Contains(count) is false)
            {
                CountDownEvent.Invoke(count);
                RecordNotified.Add(count);
            }
        }
    }
}
