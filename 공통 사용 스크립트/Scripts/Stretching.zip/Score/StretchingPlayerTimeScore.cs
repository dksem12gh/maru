using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public class StretchingPlayerTimeScore : StretchingPlayerScore
    {
        [SerializeField] StretchingStopWatchTimer timer;
        [SerializeField] TextMeshProUGUI timeText;        


        [Header("Events")]
        [SerializeField] public UnityEvent<float> ChangedTimeScoreEvent = new UnityEvent<float>();

        public float Sec
        {
            get;
            private set;
        } = 0f;

        public int SecInt => Mathf.FloorToInt(Sec);

        int OldSecInt
        {
            get; set;
        } = 0;

        public float Goal => Settings.GameTimeSecGoal;
        public int GoalInt => Mathf.FloorToInt(Settings.GameTimeSecGoal);


        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            SetTime(0, false);
        }

        public virtual void AddTime (float addSec)
        {
            SetTime(Sec + addSec, true);
            if(OldSecInt != SecInt)
                DoAnimation();
        }

        void SetTime(float time, bool notify) 
        {
            OldSecInt = SecInt;
            Sec = time;
            timeText.text = Helper.FormatToHMSFromScore(GetShowTime());
            if(notify)
                ChangedTimeScoreEvent.Invoke(Sec);
            
            int GetShowTime()
            {
                /*if (Settings.Infinite)*/ return Mathf.Max(0, Mathf.FloorToInt(Sec));
                //return InverseSec();                
            }
/*
            int InverseSec()
            {
                return Mathf.Max(0, Mathf.FloorToInt(Goal - Mathf.FloorToInt(time)));
            }*/
        }

        public override ResultData ToResultData()
        {
            return new ResultData
            {
                AllTimeSec = Mathf.FloorToInt(timer.TotalTime),
                LeftTimeSec = 0,
                CyclesCount = (int)Sec
            };
        }


        Animation anim;

        void DoAnimation()
        {
            if (anim == null)
                anim = GetComponent<Animation>();
            if (anim != null)
            {
                if(anim.isPlaying == false)
                    anim.Play();
            }
        }        
    }
}
