using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public class StretchingTotalTime : StretchingPlayerScore
    {
        [SerializeField] StretchingStopWatchTimer timer;
        [SerializeField] TextMeshProUGUI timeText;

        [Header("Events")]
        [SerializeField] public UnityEvent<float> ChangedTimeScoreEvent = new UnityEvent<float>();

        public float Sec
        {
            get;
            private set;
        } = 0f;

        public int SecInt => Mathf.FloorToInt(Sec);

        int OldSecInt
        {
            get; set;
        } = 0;


        public float Goal => Settings.GameTimeSecGoal;
        public int GoalInt => Mathf.FloorToInt(Settings.GameTimeSecGoal);

        private bool isCountingDown = false;
        private bool pause = false;

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            Sec = Goal; // Goal 시간부터 시작
            timeText.text = Helper.FormatToHMSFromSec(SecInt); // 초기 시간 텍스트 설정
            StartCountdown(); // 카운트다운 시작
        }

        public void Pause(bool pause)
        {
            this.pause = pause;
        }

        void StartCountdown()
        {
            isCountingDown = true;
        }

        void Update()
        {
            if (isCountingDown)
            {
                if (!pause)
                {
                    AddTime(-Time.deltaTime); // 매 프레임마다 1초 감소
                }
                if (Sec <= 0)
                {
                    Sec = 0;
                    isCountingDown = false; // 타이머가 0이 되면 카운트다운 중지
                }
            }
        }

        public virtual void AddTime(float addSec)
        {
            SetTime(Sec + addSec, true);
            if (OldSecInt != SecInt)
                DoAnimation();
        }

        void SetTime(float time, bool notify)
        {
            OldSecInt = SecInt;
            Sec = time;
            timeText.text = Helper.FormatToHMSFromSec(GetShowTime());
            if (notify)
                ChangedTimeScoreEvent.Invoke(Sec);

            int GetShowTime()
            {
                return InverseSec();
            }

            int InverseSec()
            {
                return Mathf.Max(0, Mathf.FloorToInt(time)); // 남은 시간 표시
            }
        }

        public override ResultData ToResultData()
        {
            return new ResultData
            {
                AllTimeSec = Mathf.FloorToInt(timer.TotalTime),
                LeftTimeSec = 0,
                CyclesCount = 0
            };
        }

        Animation anim;

        void DoAnimation()
        {
            if (anim == null)
                anim = GetComponent<Animation>();
            if (anim != null)
            {
                if (anim.isPlaying == false)
                    anim.Play();
            }
        }
    }

    /*namespace DigitalMaru.Common
    {
        public class StretchingTotalTime : StretchingPlayerScore
        {
            [SerializeField] StretchingStopWatchTimer timer;
            [SerializeField] TextMeshProUGUI timeText;

            [Header("Events")]
            [SerializeField] public UnityEvent<float> ChangedTimeScoreEvent = new UnityEvent<float>();

            public float Sec
            {
                get;
                private set;
            } = 0f;

            public int SecInt => Mathf.FloorToInt(Sec);

            int OldSecInt
            {
                get; set;
            } = 0;

            public float Goal => Settings.GameTimeSecGoal;
            public int GoalInt => Mathf.FloorToInt(Settings.GameTimeSecGoal);

            private bool isCountingDown = false;
            private bool pause = false;

            public override void Prepare(in GameSettingsBridge settings)
            {
                base.Prepare(settings);
                Sec = Goal; // Goal 시간부터 시작
                timeText.text = Helper.FormatToHMSFromSec(GetShowTime()); // 초기 시간 텍스트 설정
                StartCountdown(); // 카운트다운 시작
            }

            public void Pause(bool pause)
            {
                this.pause = pause;
            }

            void StartCountdown()
            {
                isCountingDown = true;
            }

            void Update()
            {
                if (isCountingDown)
                {
                    if (!pause)
                    {
                        AddTime(-Time.deltaTime); // 매 프레임마다 1초 감소
                    }
                    if (Sec <= 0)
                    {
                        Sec = 0;
                        isCountingDown = false; // 타이머가 0이 되면 카운트다운 중지
                    }
                }
            }

            public virtual void AddTime(float addSec)
            {
                SetTime(Sec + addSec, true);
                if (OldSecInt != SecInt)
                    DoAnimation();
            }

            void SetTime(float time, bool notify)
            {
                OldSecInt = SecInt;
                Sec = time;
                timeText.text = Helper.FormatToHMSFromSec(GetShowTime());
                if (notify)
                    ChangedTimeScoreEvent.Invoke(Sec);

                int GetShowTime()
                {
                    return InverseSec();
                }

                int InverseSec()
                {
                    return Mathf.Max(0, Mathf.FloorToInt(time)); // 남은 시간 표시
                }
            }

            public override ResultData ToResultData()
            {
                return new ResultData
                {
                    AllTimeSec = Mathf.FloorToInt(timer.TotalTime),
                    LeftTimeSec = SecInt,
                    CyclesCount = 0
                };
            }

            Animation anim;

            void DoAnimation()
            {
                if (anim == null)
                    anim = GetComponent<Animation>();
                if (anim != null)
                {
                    if (anim.isPlaying == false)
                        anim.Play();
                }
            }
        }
    }*/
}