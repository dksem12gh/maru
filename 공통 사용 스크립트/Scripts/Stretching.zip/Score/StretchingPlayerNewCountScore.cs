using TMPro;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class StretchingPlayerNewCountScore : StretchingPlayerScore
    {
        [SerializeField] StretchingStopWatchTimer timer;
        [SerializeField] TextMeshProUGUI countText;

        int score;

        public int Score
        {
            get => score;                        
        }

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            SetScore(0);
        }

        public virtual void ScoreUp()
        {
            SetScore(score + 1);
        }

        void SetScore (int value)
        {
            score = value;
            countText.text = score.ToString();            
        }

        public override ResultData ToResultData()
        {
            return new ResultData()
            {
                AllTimeSec = Mathf.FloorToInt(timer.TotalTime),
                LeftTimeSec = 0,
                CyclesCount = Score,
            };
        }
    }
}