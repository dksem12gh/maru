using TMPro;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.Common
{
    public class StretchingPlayerCountTimeScore : StretchingPlayerScore
    {
        [SerializeField] StretchingStopWatchTimer timer;
        [SerializeField] TextMeshProUGUI countText;

        [Header("Events")]
        [SerializeField] public UnityEvent<float> ChangedTimeScoreEvent = new UnityEvent<float>();

        int score;

        public int Score
        {
            get => score;                                    
        }
        public float Sec
        {
            get;
            private set;
        } = 0f;

        public int SecInt => Mathf.FloorToInt(Sec);

        int Goal => Settings.GameCountGoal;

        bool Infinite => Settings.Infinite;                

        public override void Prepare(in GameSettingsBridge settings)
        {
            base.Prepare(settings);
            SetScore(0);
            SetTime(0, false);
        }

        public virtual void AddTime(float addSec)
        {
            SetTime(Sec + addSec, true);            
        }

        void SetTime(float time, bool notify)
        {
            Sec = time;
            if (notify)
                ChangedTimeScoreEvent.Invoke(Sec);
        }

        public virtual void ScoreUp()
        {
            SetScore(score + 1);
        }

        void SetScore (int value)
        {
            score = value;
            if (Infinite)
                countText.text = score.ToString();
            else
                countText.text = (Goal - score).ToString();
        }

        public override ResultData ToResultData()
        {
            return new ResultData()
            {
                AllTimeSec = 0,
                LeftTimeSec = 0,
                CyclesCount = Score,
            };
        }
    }
}