using UnityEngine;

namespace DigitalMaru.Common
{
    public abstract class StretchingPlayerScore : MonoBehaviour
    {
        GameSettingsBridge settings = null;
        protected GameSettingsBridge Settings => settings ?? new GameSettingsBridge();

        public virtual void Prepare(in GameSettingsBridge settings)
        {
            this.settings = settings;
        }
        abstract public ResultData ToResultData();
    }
}
