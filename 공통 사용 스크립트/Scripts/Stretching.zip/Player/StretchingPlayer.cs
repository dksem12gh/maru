using UnityEngine;


namespace DigitalMaru.Common
{
    public abstract class StretchingPlayer : MonoBehaviour
    {        
        abstract public bool Completed { get; }
        abstract public void Prepare(GameSettingsBridge settings);
        abstract public void Do();
        abstract public void Pause(bool pause);
        abstract public ResultData ToResultData();        
    }
}
