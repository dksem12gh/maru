using UnityEngine;

namespace DigitalMaru.Common
{
    public class SimpleStretchingPlayer : StretchingPlayer
    {
        [Header("Main Reference")]
        [SerializeField] private StretchingRule rule;
        [SerializeField] private StretchingPlayerScore playerScore;
        [SerializeField] private TouchPad touchPad;

        public override bool Completed => rule.Completed;

        //void OnEnable()
        //{
        //    touchPad.TouchPressedChanged += OnTouch;
        //}

        //void OnDisable()
        //{
        //    touchPad.TouchPressedChanged -= OnTouch;
        //}

        public override void Prepare(GameSettingsBridge settings)
        {
            playerScore.Prepare(settings);
            rule.Prepare(settings);
        }

        public override void Do()
        {
            rule.Begin(touchPad);
        }      

        public override void Pause(bool pause)
        {
            if (Completed is false)
            {
                rule.Pause(pause);
                touchPad.SetLock(pause);
            }
        }

        //void OnTouch(TouchPad touchPad)
        //{
        //    rule.Touch(touchPad);
        //}

        public override ResultData ToResultData() => playerScore.ToResultData();
    }
}
