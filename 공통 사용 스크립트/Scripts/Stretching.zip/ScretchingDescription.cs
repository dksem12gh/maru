using TMPro;
using UnityEngine;

namespace DigitalMaru.Common
{
    public class ScretchingDescription : MonoBehaviour
    {
        [SerializeField] private TextMeshProUGUI descText;

        public void SetDesc(string desc)
        {
            descText.text = desc;
        }
    }
}
