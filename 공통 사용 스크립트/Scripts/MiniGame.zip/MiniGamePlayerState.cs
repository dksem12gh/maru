namespace DigitalMaru.MiniGame
{
    public enum PLAYER_STATE
    {
        NONE = 0,
        PLAYING = 1,
        FAIL = 2,
        WAIT = 3,
    }
}