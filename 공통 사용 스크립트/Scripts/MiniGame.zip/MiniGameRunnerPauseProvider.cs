using System;

namespace DigitalMaru.MiniGame
{
    /// <summary>
    /// 이 클래스는 MiniGame Runner에서 호출 되는 Pause Provider이다.
    /// </summary>
    public class MiniGameRunnerPauseProvider : IDisposable
    {
        static Lazy<MiniGameRunnerPauseProvider> instance = new Lazy<MiniGameRunnerPauseProvider>(New);
        static public MiniGameRunnerPauseProvider Instance => instance.Value;
        static MiniGameRunnerPauseProvider New()
        {
            return new MiniGameRunnerPauseProvider();
        }
        static public bool Alive { get; set; } = false;

        public event Action<bool> PauseChangedEvent;

        MiniGameRunnerPauseProvider()
        {
            Alive = true;
        }

        ~MiniGameRunnerPauseProvider() { }

        public void Dispose()
        {
            instance = new Lazy<MiniGameRunnerPauseProvider>(New);
            Alive = false;
        }

        public void Pause(bool pause)
        {
            PauseChangedEvent?.Invoke(pause);
        }
    }
}
