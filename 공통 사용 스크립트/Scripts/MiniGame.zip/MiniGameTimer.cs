using TMPro;
using UnityEngine;
using System.Collections;

namespace DigitalMaru.MiniGame
{
    public class MiniGameTimer : MonoBehaviour
    {
        [SerializeField] private int PlayTimeSec = 180;
        [SerializeField] private TextMeshProUGUI timeText;


        bool running = false;
        
        int LeftTimeSecInt => Mathf.Max(0, Mathf.CeilToInt(PlayTimeSec - timeSec));

        float timeSec = 0;
        Coroutine timerRoutine = null;
        public bool CheckTimeout() => CheckTimeout(PlayTimeSec);

        public void Prepare()
        {
            SetTime(0);
        }

        public void StartTimer()
        {
            if (running) return;

            StopTimer();
            timeSec = 0f;
            running = true;
            timerRoutine = StartCoroutine(TimerRoutine(PlayTimeSec));
        }

        public void StopTimer()
        {
            if (null != timerRoutine)
            {
                StopCoroutine(timerRoutine);
                timerRoutine = null;
            }
        }

        public void Pause(bool pause)
        {
            if (running is false) return;

            if(pause)
                StopTimer();
            else
                timerRoutine = StartCoroutine(TimerRoutine(PlayTimeSec));
        }

        IEnumerator TimerRoutine(int playTimeSec)
        {    
            while (CheckTimeout(playTimeSec) is false)
            {
                yield return YieldInstructionCache.WaitForFixedUpdate;                                
                SetTime(timeSec + Time.fixedDeltaTime);
            }
            timerRoutine = null;
            running = false;
        }

        bool CheckTimeout(int playTimeSec) => playTimeSec <= timeSec;

        void SetTime(float value)
        {
            timeSec = value;
            if(timeText != null)
                timeText.text = Helper.FormatToHMSFromSec(LeftTimeSecInt);
        }
    }
}
