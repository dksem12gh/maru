using UnityEngine;

namespace DigitalMaru.MiniGame
{
    public enum MiniGameResultState
    {
        Draw,
        Win1P,
        Win2P
    }

    public class MiniGameResultWindow : MonoBehaviour
    {
        [SerializeField] private GameObject win1p;
        [SerializeField] private GameObject win2p;
        [SerializeField] private GameObject draw;

        public void Show(MiniGameResultState result)
        {
            switch (result)
            {
                case MiniGameResultState.Draw: 
                    ShowDraw();
                    break;
                case MiniGameResultState.Win1P:
                    ShowWin1P();
                    break;
                case MiniGameResultState.Win2P:
                    ShowWin2P();
                    break;
            }
        }
        void ShowDraw()
        {
            draw.SetActive(true);
        }

        void ShowWin1P()
        {
            win1p.SetActive(true);
        }

        void ShowWin2P()
        {
            win2p.SetActive(true);
        }
    }
}
