using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace DigitalMaru.MiniGame
{
    public abstract class MiniGameRule : MonoBehaviour
    {
        [Header("Events")]
        public UnityEvent RunEvent = new UnityEvent();
        public UnityEvent SuccessEvent = new UnityEvent();
        public UnityEvent FailEvent = new UnityEvent();
        public UnityEvent StartEvent = new UnityEvent();
        public UnityEvent CompletedEvent = new UnityEvent();
        
        GameSettingsBridge settings = null;
        protected GameSettingsBridge Settings => settings ?? new GameSettingsBridge();

        abstract public bool Completed { get;}

        public virtual void Do()
        {
        }

        public virtual void Begin()
        {
        }

        public virtual void Prepare()
        {
        }
        
        public virtual void Pause(bool _pause)
        {
        }

        public virtual void Result()
        {
        }

        public virtual int[] GetResultData()
        {
            return new int[0];
        }
    }
    
}