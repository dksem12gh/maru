using UnityEngine;
using UnityEngine.Events;


namespace DigitalMaru.MiniGame
{
    public class MiniGamePauseListener : MonoBehaviour
    {
        [SerializeField] private UnityEvent<bool> PauseEvent = new UnityEvent<bool>();

        private void OnEnable()
        {
            MiniGameRunnerPauseProvider.Instance.PauseChangedEvent += OnPause;
        }

        private void OnDisable()
        {
            if (MiniGameRunnerPauseProvider.Alive)
                MiniGameRunnerPauseProvider.Instance.PauseChangedEvent -= OnPause;
        }

        void OnPause(bool pause)
        {
            PauseEvent.Invoke(pause);
        }
    }
}
