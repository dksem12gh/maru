using System.Collections;
using UnityEngine;


namespace DigitalMaru.MiniGame
{
    public abstract class MiniGameRunner : MonoBehaviour
    {
        protected virtual void OnDestroy()
        {
            if (MiniGameRunnerPauseProvider.Alive)
                MiniGameRunnerPauseProvider.Instance.Dispose();
        }

        abstract public void Prepare();
        abstract public IEnumerator Run();
        public void Pause(bool pause)
        {
            PauseHandle(pause);
            MiniGameRunnerPauseProvider.Instance.Pause(pause);
        }

        abstract public MiniGameResultState GetResult();
        abstract protected void PauseHandle(bool pause);
    }
}
