using System.Collections;
using UnityEngine;

namespace DigitalMaru.MiniGame
{
    public class MiniGameManager : MultiDisplayTouchGameManager
    {
        [SerializeField] TitleWindowFactory titleWindowFactory;
        [SerializeField] MiniGameRunner runner;
        [SerializeField] GameObject resultWindow;

        [System.Serializable]
        public class Extra
        {
            public bool use = false;
            public Vector3 localPosition = Vector3.zero;
            public float localScale = 1.0f;
        }
        [Header("추가 설정")]
        [SerializeField] Extra extraResultWindow;


        enum MiniGameState
        {
            None,
            Init,
            Title,
            Run,
            Result
        }

        MiniGameState gameState = MiniGameState.None;

        protected override IEnumerator DoInit()
        {
            gameState = MiniGameState.Init;
            runner.Prepare();
            yield return null;
        }

        protected override IEnumerator DoTitle()
        {
            gameState = MiniGameState.Title;
            yield return titleWindowFactory.CreateAndRemoveWithDelayed();
        }
        
        protected override IEnumerator DoRun()
        {
            gameState = MiniGameState.Run;
            yield return runner.Run();
        }

        protected override IEnumerator DoResult()
        {
            gameState = MiniGameState.Result;
            var wnd = Instantiate(resultWindow, transform).GetComponent<MiniGameResultWindow>();
            if (extraResultWindow.use)
            {
                wnd.transform.localPosition = extraResultWindow.localPosition;
                wnd.transform.localScale = wnd.transform.localScale * extraResultWindow.localScale;
            }
            wnd.Show(runner.GetResult());
            yield return null;
        }

        protected override void OnPause(bool pause)
        {
            switch (gameState)
            {
                case MiniGameState.Run:
                    runner.Pause(pause);
                    break;
            }
        }
    }
}
