using UnityEngine;


namespace DigitalMaru
{
    public class TitleWindow : MonoBehaviour
    {
        [SerializeField] private TMPro.TextMeshProUGUI titleText;
        
        public void SetTitle(string title)
        {
            titleText.text = title;
        }
    }
}
