using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace DigitalMaru
{
    public struct ResultData
    {
        public int AllTimeSec;
        public int LeftTimeSec;
        public int CyclesCount;
    }

    public class ResultWindow : MonoBehaviour
    {
        [SerializeField] TMP_Text[] _resultPrivateTime = new TMP_Text[2];
        [SerializeField] TMP_Text[] _resultCountTxt = new TMP_Text[2];
        [SerializeField] TMP_Text _resultTotalTimeTxt;
        [SerializeField] TMP_Text[] _resultTotalCountTxt = new TMP_Text[2];
        [Space]
        [SerializeField] Animator _resultAni;


        public void Show()
        {
            gameObject.SetActive(true);
        }

        public void PlayAniTimeCount()
        {
            _resultAni.Play("2인_개인시간_횟수");
        }

        public void PlayAniSingleTime()
        {
            _resultAni.Play("2인_개인시간");
        }        

        public void PlayAniCount()
        {
            _resultAni.Play("2인_횟수");
        }

        public void PlayTotalScore()
        {
            _resultAni.Play("통합_시간횟수");
        }

        public void SetDataTimeCount(ResultData[] datas)
        {
            for (int i = 0; i < 2; i++)
            {
                int checkAlltime = Mathf.Abs(datas[i].AllTimeSec - datas[i].LeftTimeSec);
                int hour = Mathf.FloorToInt(checkAlltime / 3600);
                int minutes = Mathf.FloorToInt(checkAlltime % 3600 / 60);
                int seconds = Mathf.FloorToInt(checkAlltime % 60);
                string timeText = string.Format("{0:00}:{1:00}:{2:00}", hour, minutes, seconds);

                _resultPrivateTime[i].text = timeText;
                _resultCountTxt[i].text = (datas[i].CyclesCount).ToString();
            }
        }

        public void SetDataCount(ResultData[] datas)
        {
            for (int i = 0; i < datas.Length; i++)
            {                
                _resultCountTxt[i].text = (datas[i].CyclesCount).ToString();
            }
        }

        public void SetTotal(ResultData[] datas)
        {
            int checkAlltime = Mathf.Abs(datas[0].AllTimeSec - datas[0].LeftTimeSec);
            int hour = Mathf.FloorToInt(checkAlltime / 3600);
            int minutes = Mathf.FloorToInt(checkAlltime % 3600 / 60);
            int seconds = Mathf.FloorToInt(checkAlltime % 60);
            string timeText = string.Format("{0:00}:{1:00}:{2:00}", hour, minutes, seconds);

            _resultTotalTimeTxt.text = timeText;
            for (int i = 0; i < 2; i++)
            {
                _resultTotalCountTxt[i].text = (datas[i].CyclesCount).ToString();
            }
        }
    }
}