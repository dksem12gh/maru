using UnityEngine;

namespace DigitalMaru
{
    public class ResultWindowWithSound : MonoBehaviour
    {
        [SerializeField] ResultWindow ResultWnd;

        public void ShowTime (params ResultData[] datas)
        {
            ResultWnd.SetDataTimeCount(datas);
            ResultWnd.Show();
            ResultWnd.PlayAniTimeCount();
        }

        public void ShowCount(params ResultData[] datas)
        {
            ResultWnd.SetDataCount(datas);
            ResultWnd.Show();
            ResultWnd.PlayAniCount();
        }
    }
}
