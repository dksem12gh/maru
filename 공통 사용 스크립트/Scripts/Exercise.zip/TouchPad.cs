using System;
using UnityEngine;

namespace DigitalMaru.Exercise
{
    public abstract class TouchPad : MonoBehaviour
    {
        public event Action<TouchPad> TouchEvent;

        abstract public int Len { get; }

        abstract public bool AnyPressed { get; }
        abstract public bool FailPressed { get; }

        abstract public bool AllPressed { get; }
        abstract public void ResetTouch();
        abstract public void SetLock(bool isLock);        

        abstract public void SetActive(bool value);

        abstract public bool TryGetTouch(int index, out Touch touch);
        abstract public bool GetPressed(int index);

        protected void InvokeTouchEvent()
        {
            TouchEvent?.Invoke(this);
        }
    }
}
