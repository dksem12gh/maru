using System.Collections;
using UnityEngine;
using UnityEngine.Events;


namespace DigitalMaru.Exercise
{
    public abstract class ExerciseGameRunner : MonoBehaviour
    {
        [Header("events")]
        [SerializeField] protected UnityEvent PrepareRunnerEvent = new UnityEvent();
        [SerializeField] protected UnityEvent StartRunnerEvent = new UnityEvent();
        [SerializeField] protected UnityEvent EndRunnerEvent = new UnityEvent();
        [SerializeField] protected UnityEvent<bool> PauseRunnerEvent = new UnityEvent<bool>();

        abstract public void Prepare();
        abstract public IEnumerator Run();
        abstract public ResultData[] GetResultData();
        abstract public void Pause(bool pause);
    }
}
